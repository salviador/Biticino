import logging
import time
import json
import uuid
import urllib3
import boto3
from boto3.dynamodb.conditions import Key, Attr



class AutorizzazioneEventi:
    def __init__(self, client_id , client_secret):
        self.client_id = client_id
        self.client_secret = client_secret

    def get_authorization_code(self,code):
        access_token = " "
        refresh_token = " "
        url = 'https://api.amazon.com/auth/o2/token'
        hdr = { 'content-type' : 'application/x-www-form-urlencoded' , 'charset' : 'UTF-8'}
        s = 'grant_type=authorization_code&code=' + code + '&client_id=' + self.client_id + '&client_secret=' + self.client_secret
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        http = urllib3.PoolManager()            
        r = http.request("POST", url, body=s,headers=hdr)
        data_token = json.loads(r.data.decode('utf-8'))
        if "access_token" in data_token:
            access_token = data_token['access_token']
            refresh_token = data_token['refresh_token']
        return access_token, refresh_token