import json
import logging
import time
import uuid



logger = logging.getLogger()
logger.setLevel(logging.INFO)



class Dispositivi:
    def __init__(self):
        self.dispositivi = [
           
            #switch e light
            {"endpointId": "endpoint-001", "manufacturerName": "fabri", "friendlyName": "CucinaLavoro", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-002", "manufacturerName": "fabri", "friendlyName": "CucinaTavolo", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-003", "manufacturerName": "fabri", "friendlyName": "SalaFaretti1", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-004", "manufacturerName": "fabri", "friendlyName": "SalaFaretti2", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-005", "manufacturerName": "fabri", "friendlyName": "SalaVela1", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-006", "manufacturerName": "fabri", "friendlyName": "SalaVela2", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-007", "manufacturerName": "fabri", "friendlyName": "Studio", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-008", "manufacturerName": "fabri", "friendlyName": "StudioFaretti", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-009", "manufacturerName": "fabri", "friendlyName": "CorridoioGiorno", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-010", "manufacturerName": "fabri", "friendlyName": "PorteG", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-011", "manufacturerName": "fabri", "friendlyName": "BagnoPiccolo", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-012", "manufacturerName": "fabri", "friendlyName": "Cameretta", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-013", "manufacturerName": "fabri", "friendlyName": "CamerettaArmadio", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-014", "manufacturerName": "fabri", "friendlyName": "NotturnaMia", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-015", "manufacturerName": "fabri", "friendlyName": "NotturnaAndrea", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-016", "manufacturerName": "fabri", "friendlyName": "WcSpecchio", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-017", "manufacturerName": "fabri", "friendlyName": "WcVasca", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-018", "manufacturerName": "fabri", "friendlyName": "WcBidet", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-019", "manufacturerName": "fabri", "friendlyName": "CameraGrande", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-020", "manufacturerName": "fabri", "friendlyName": "CabinaArmadio", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-021", "manufacturerName": "fabri", "friendlyName": "ComodinoFabrizio", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-022", "manufacturerName": "fabri", "friendlyName": "ComodinoEleonora", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-023", "manufacturerName": "fabri", "friendlyName": "CorridoioNotte", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            {"endpointId": "endpoint-024", "manufacturerName": "fabri", "friendlyName": "PorteNotte", "description": "casa fabri luce", "displayCategories": ["LIGHT"], "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}, "capabilities": [{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa.EndpointHealth", "version": "3", "properties": {"supported": [{"name": "connectivity"}], "proactivelyReported": True, "retrievable": True}}, {"type": "AlexaInterface", "interface": "Alexa", "version": "3"}]},
            
            #campanello
            {"endpointId": "doorbell-01", "manufacturerName": "miki","modelName": "Helios IP doorbell","friendlyName": "IngressoSscala","description": "Helios IP doorbell and intercom","displayCategories": [ "DOORBELL" ],"cookie": {},"capabilities": [{"type": "AlexaInterface", "interface": "Alexa.DoorbellEventSource", "version": "3","proactivelyReported": True}]},

            #sensore temperatura
            {"endpointId": "sensore-001","manufacturerName": "miki","description": "Sesnore Temperatura","friendlyName": "zona notte","displayCategories": ["TEMPERATURE_SENSOR"],"cookie": {},"capabilities": [{"type": "AlexaInterface","interface": "Alexa.TemperatureSensor","version": "3","properties": {"supported": [{"name": "temperature"}],"proactivelyReported": True,"retrievable": True}},{"type": "AlexaInterface","interface": "Alexa","version": "3"}]},
            
            #termostato
            {"endpointId": "thermostat-001","friendlyName": "termostato","description": "termostato Bticino","manufacturerName": "fabri","displayCategories": ["THERMOSTAT"],"cookie": {  },"capabilities": [{"type": "AlexaInterface","interface": "Alexa.ThermostatController","version": "3","properties": {"supported": [{"name": "lowerSetpoint"},{"name": "targetSetpoint"},{"name": "upperSetpoint"},{"name": "thermostatMode"}],"proactivelyReported": True,"retrievable": True},"configuration": {"supportsScheduling": False,"supportedModes": ["HEAT","COOL","AUTO","OFF"]}},{"type": "AlexaInterface","interface": "Alexa.TemperatureSensor","version": "3","properties": {"supported": [{"name": "temperature"}],"proactivelyReported": True,"retrievable": True}}]},
            
            #serratura
            {"endpointId":"locked-001","manufacturerName":"fabri","description":"serraturaportone","friendlyName":"portone","displayCategories":["SMARTLOCK"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.LockController","version":"3","properties":{"supported":[{"name":"lockState"}],"proactivelyReported":True,"retrievable":True}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},

            #serrande o tapparelle
            {"endpointId":"tapparella-001","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"PianoCottura","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-002","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"PortaCucina","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-003","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"Camino","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-004","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"PortaSala","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-005","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"Sala","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-006","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"Studio","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-007","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"WCPiccolo","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-008","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"Cameretta","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-009","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"WCGrande","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            {"endpointId":"tapparella-010","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"CameraGrande","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},

            #nuova serranda
            {"endpointId":"tapparella-011","manufacturerName":"fabri","description":"gestiscetapparella","friendlyName":"finestra","displayCategories":["INTERIOR_BLIND"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.RangeController","instance":"Blind.Lift","version":"3","properties":{"supported":[{"name":"rangeValue"}],"proactivelyReported":True,"retrievable":True},"capabilityResources":{"friendlyNames":[{"@type":"asset","value":{"assetId":"Alexa.Setting.Opening"}}]},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":1},"unitOfMeasure":"Alexa.Unit.Percent"},"semantics":{"actionMappings":[{"@type":"ActionsToDirective","actions":["Alexa.Actions.Close"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":0}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Open"],"directive":{"name":"SetRangeValue","payload":{"rangeValue":100}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Lower"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta": 0,"rangeValueDeltaDefault":False}}},{"@type":"ActionsToDirective","actions":["Alexa.Actions.Raise"],"directive":{"name":"AdjustRangeValue","payload":{"rangeValueDelta":100,"rangeValueDeltaDefault":False}}}],"stateMappings":[{"@type":"StatesToValue","states":["Alexa.States.Closed"],"value":0},{"@type":"StatesToRange","states":["Alexa.States.Open"],"range":{"minimumValue":0,"maximumValue":100}}]}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]},
            
            #Dimmer
            {"endpointId":"dimmer-001","manufacturerName":"fabri","description":"dimmer","friendlyName":"dimmer","displayCategories":["LIGHT"],"cookie":{},"capabilities":[{"type":"AlexaInterface","interface":"Alexa.BrightnessController","version":"3","properties":{"supported":[{"name":"brightness"}],"proactivelyReported":True,"retrievable":True},"configuration":{"supportedRange":{"minimumValue":0,"maximumValue":100,"precision":10},"unitOfMeasure":"Alexa.Unit.Percent"}},{"type": "AlexaInterface", "interface": "Alexa.PowerController", "version": "3", "properties": {"supported": [{"name": "powerState"}], "proactivelyReported": True, "retrievable": True}},{"type":"AlexaInterface","interface":"Alexa","version":"3"}]}


        ]



    def get_Dispositivi(self):
        s = {"event": {"header": {"namespace": "Alexa.Discovery", "name": "Discover.Response", "payloadVersion": "3", "messageId": "e46b169c-4022-40f2-8196-8ae93fca1f34"}, "payload": {"endpoints": self.dispositivi }}}
        #return json.loads(s)
        return s

    def get_State_Device(self, dynamodb, id_device, token):
        dispraw = self.get_Dispositivi()
        disp = dispraw['event']['payload']['endpoints']

        for dev in disp:
            if((dev['capabilities'][0]['interface'] == 'Alexa.PowerController') and (dev['endpointId'] == id_device)):
                value = "OFF"

                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device}})
                if 'Item' in risp:
                    item = risp['Item']
                    value = item['stato']['S']
                    
                risposta = '{"context": {"properties": [{"namespace": "Alexa.PowerController", "name": "powerState", "value": "' + value + '", "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '", "uncertaintyInMilliseconds": 500}]}, "event": {"header": {"namespace": "Alexa", "name": "StateReport", "payloadVersion": "3", "messageId": "' + str(uuid.uuid4()) + '", "correlationToken": "' + token + '"}, "endpoint": {"scope": {"type": "BearerToken", "token": "access-token-from-Amazon"}, "endpointId": "' + id_device + '", "cookie": {}}, "payload": {}}}'
                return "Alexa.PowerController", value, risposta

            elif((dev['capabilities'][0]['interface'] == 'Alexa.BrightnessController') and (dev['endpointId'] == id_device)):
                
                value2x = "OFF"
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device}})
                if 'Item' in risp:
                    item = risp['Item']
                    value2x = item['stato']['S']
                value = "0"
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device + '_S' }})
                if 'Item' in risp:
                    item = risp['Item']
                    value = item['stato']['S']
                                

                risposta = '{"context": {"properties": [{"namespace": "Alexa.BrightnessController", "name": "brightness", "value":'  + value + ', "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '", "uncertaintyInMilliseconds": 500},{"namespace": "Alexa.PowerController", "name": "powerState", "value": "' + value2x + '", "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '", "uncertaintyInMilliseconds": 500}]}, "event": {"header": {"namespace": "Alexa", "name": "StateReport", "payloadVersion": "3", "messageId": "' + str(uuid.uuid4()) + '", "correlationToken": "' + token + '"}, "endpoint": {"scope": {"type": "BearerToken", "token": "access-token-from-Amazon"}, "endpointId": "' + id_device + '", "cookie": {}}, "payload": {}}}'
                return "Alexa.BrightnessController", value, risposta
            
            elif((dev['capabilities'][0]['interface'] == 'Alexa.TemperatureSensor') and (dev['endpointId'] == id_device)):
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device}})
                if 'Item' in risp:
                    item = risp['Item']
                    value_Temp = item['stato']['S']

                    risposta = '{"event":{"header":{"namespace":"Alexa","name":"StateReport","messageId":"'+str(uuid.uuid4())+'","correlationToken":"'+token+'","payloadVersion":"3"},"endpoint":{"endpointId":"'+id_device+'"},"payload":{}},"context":{"properties":[{"namespace":"Alexa.TemperatureSensor","name":"temperature","value":{"value":"'+value_Temp+'","scale":"CELSIUS"},"timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds":1000}]}}'
                    return "Alexa.TemperatureSensor", value_Temp, risposta

            elif((dev['capabilities'][0]['interface'] == 'Alexa.ThermostatController') and (dev['endpointId'] == id_device)):
                #{"target" : 12, "mode" : "AUTO" , "temp": 21.4}

                t_temp = "0"
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device + "_T"}})
                if 'Item' in risp:
                    item = risp['Item']
                    value_Temp = item['stato']['S']
                    t_temp = value_Temp
                    
                t_target = "0"
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device + "_S"}})
                if 'Item' in risp:
                    item = risp['Item']
                    value_Temp = item['stato']['S']
                    t_target = value_Temp

                t_mode ="OFF"
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device + "_M"}})
                if 'Item' in risp:
                    item = risp['Item']
                    value_Temp = item['stato']['S']
                    if(value_Temp=="3"):
                        t_mode ="COOL"
                    if(value_Temp=="4"):
                        t_mode ="HEAT"
                    if(value_Temp=="5"):
                        t_mode ="OFF"

                risposta = '{"event":{"header":{"namespace":"Alexa","name":"StateReport","messageId":"'+str(uuid.uuid4())+'","correlationToken":"'+token+'","payloadVersion":"3"},"endpoint":{"endpointId":"'+id_device+'"},"payload":{}},"context":{"properties":[{"namespace":"Alexa.ThermostatController","name":"thermostatMode","value":"'+t_mode+'","timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds":500},{"namespace":"Alexa.ThermostatController","name":"targetSetpoint","value":{"value":"'+str(t_target)+'","scale":"CELSIUS"},"timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds":500},{"namespace":"Alexa.TemperatureSensor","name":"temperature","value":{"value":"'+str(t_temp)+'","scale":"CELSIUS"},"timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds":1000}]}}'
                return "Alexa.TemperatureSensor", "", risposta

                    
            elif((dev['capabilities'][0]['interface'] == 'Alexa.LockController') and (dev['endpointId'] == id_device)):
                value = "LOCKED"
                baretoken = token

                risposta = '{"event":{"header":{"namespace":"Alexa","name":"StateReport","messageId":"'+str(uuid.uuid4())+'","correlationToken":"'+token+'","payloadVersion":"3"},"endpoint":{"scope":{"type":"BearerToken","token":"'+baretoken+'"},"endpointId":"'+id_device+'"},"payload":{}},"context":{"properties":[{"namespace":"Alexa.LockController","name":"lockState","value":"'+value+'","timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds":1000}]}}'
                
                return "Alexa.LockController", value, risposta

            elif((dev['capabilities'][0]['interface'] == 'Alexa.RangeController') and (dev['endpointId'] == id_device)):
                value = "0"
                baretoken = token

                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device}})
                if 'Item' in risp:
                    item = risp['Item']
                    value = item['stato']['S']

                risposta = '{"event": {"header": {"namespace": "Alexa","name": "StateReport","messageId": "'+str(uuid.uuid4())+'","correlationToken": "'+token+'","payloadVersion": "3"},"endpoint": {"scope": {"type": "BearerToken","token": "'+baretoken+'"},"endpointId": "'+id_device+'"},"payload":{}},"context": {"properties": [{"namespace": "Alexa.RangeController","instance": "Blind.Lift","name": "rangeValue","value": ' + value + ',"timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds": 1000}]}}'
                return "Alexa.RangeController", value, risposta
             
                
                    

        return None,None

    def set_State_Device(self, dynamodb, mqtt,tipo, stato, id_device, token, data):
        logger.info("[*****set_State_Device******")
        logger.info(tipo)
        logger.info(stato)
        logger.info(id_device)

        dispraw = self.get_Dispositivi()
        disp = dispraw['event']['payload']['endpoints']

        for dev in disp:
            if((dev['capabilities'][0]['interface'] == 'Alexa.PowerController') and (dev['endpointId'] == id_device)):

                vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": stato, "identificativo": id_device}))
                value = "OFF"
                if (stato == "TurnOn"):
                    value = "ON"
                    
                risposta = '{"context": {"properties": [{"namespace": "Alexa.PowerController", "name": "powerState", "value": "' + value + '", "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '", "uncertaintyInMilliseconds": 500}]}, "event": {"header": {"namespace": "Alexa", "name": "Response", "payloadVersion": "3", "messageId": "' + str(uuid.uuid4()) + '", "correlationToken": "' + token + '"}, "endpoint": {"scope": {"type": "BearerToken", "token": "access-token-from-Amazon"}, "endpointId": "' + id_device + '"}, "payload": {}}}'
                return "Alexa.PowerController", value, risposta


            elif((dev['capabilities'][0]['interface'] == 'Alexa.BrightnessController') and (dev['endpointId'] == id_device)):
                value3x = "OFF"
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device}})
                if 'Item' in risp:
                    item = risp['Item']
                    value3x = item['stato']['S']
                value4x = "0"
                risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device + '_S' }})
                if 'Item' in risp:
                    item = risp['Item']
                    value4x = item['stato']['S']

                if(tipo == 'Alexa.PowerController'):
                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": stato, "identificativo": id_device}))
                    
                    if (stato == "TurnOn"):
                        value3x = "ON"
                    else:
                        value3x = "OFF"

                    
                    risposta = '{"context": {"properties": [{"namespace": "Alexa.PowerController", "name": "powerState", "value": "' + value3x + '", "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '", "uncertaintyInMilliseconds": 500}]}, "event": {"header": {"namespace": "Alexa", "name": "Response", "payloadVersion": "3", "messageId": "' + str(uuid.uuid4()) + '", "correlationToken": "' + token + '"}, "endpoint": {"scope": {"type": "BearerToken", "token": "access-token-from-Amazon"}, "endpointId": "' + id_device + '"}, "payload": {}}}'

                    return "Alexa.PowerController", value3x, risposta
                    
                elif((tipo == 'Alexa.BrightnessController')&(stato == 'SetBrightness')):
                    value4x = str(data['directive']['payload']['brightness'])
                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": stato, "identificativo": id_device, "p": value4x}))
                    risposta = '{"context": {"properties": [{"namespace": "Alexa.BrightnessController", "name": "brightness", "value": "' + value4x + '", "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '", "uncertaintyInMilliseconds": 500}]}, "event": {"header": {"namespace": "Alexa", "name": "Response", "payloadVersion": "3", "messageId": "' + str(uuid.uuid4()) + '", "correlationToken": "' + token + '"}, "endpoint": {"scope": {"type": "BearerToken", "token": "access-token-from-Amazon"}, "endpointId": "' + id_device + '"}, "payload": {}}}'
        
                    return "Alexa.BrightnessController", value4x, risposta                

                elif((tipo == 'Alexa.BrightnessController')&(stato == 'AdjustBrightness')):
                    valueDx = str(data['directive']['payload']['brightnessDelta'])
                    
                    delta1 = int(value4x) + int(valueDx)
                    if(delta1 > 100):
                        delta1 = 100
                    if(delta1 < 0):
                        delta1 = 0

                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": 'SetBrightness', "identificativo": id_device, "p": str(delta1)}))
                    risposta = '{"context": {"properties": [{"namespace": "Alexa.BrightnessController", "name": "brightness", "value": "' + str(delta1) + '", "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '", "uncertaintyInMilliseconds": 500}]}, "event": {"header": {"namespace": "Alexa", "name": "Response", "payloadVersion": "3", "messageId": "' + str(uuid.uuid4()) + '", "correlationToken": "' + token + '"}, "endpoint": {"scope": {"type": "BearerToken", "token": "access-token-from-Amazon"}, "endpointId": "' + id_device + '"}, "payload": {}}}'
        
                    return "Alexa.BrightnessController", value4x, risposta                


            elif((dev['capabilities'][0]['interface'] == 'Alexa.ThermostatController') and (dev['endpointId'] == id_device)):
                if(stato=="SetTargetTemperature"):
                    #imposta 12,3 fradi il termostato
                    
                    Temp_target = data['directive']['payload']['targetSetpoint']['value']
                    
                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": "temp",  "t" : Temp_target, "identificativo": id_device}))
                    
                    risposta = '{"event": {"header": {"namespace": "Alexa","name": "Response","messageId": "' + str(uuid.uuid4()) + '","correlationToken": "'+ token +'","payloadVersion": "3"},"endpoint": {"endpointId": "' + id_device + '"},"payload": {}},"context": {"properties": [{"namespace": "Alexa.ThermostatController","name": "targetSetpoint","value": {"value": "' + str(Temp_target) + '","scale": "CELSIUS"},"timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '","uncertaintyInMilliseconds": 500}]}}'
                    return "Alexa.ThermostatController", Temp_target, risposta
                    
                elif(stato=="SetThermostatMode"):
                    #imposta su raffreddamento il termostato  , dire freddo
                    #imposta su riscaldamento il termostato
                    #imposta termostato su off
                    
                    Temp_target = data['directive']['payload']['thermostatMode']['value']
                    if(Temp_target == "HEAT"):
                        mode = 'H'
                    elif(Temp_target == "COOL"):
                        mode = 'C'
                    elif(Temp_target == "AUTO"):
                        mode = 'A'
                    elif(Temp_target == "OFF"):
                        mode = 'O'
                    else:
                        mode = 'O'
                    
                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": "mode" , "m" : mode, "identificativo": id_device}))
                    
                    risposta = '{"event": {"header": {"namespace": "Alexa","name": "Response","messageId": "' + str(uuid.uuid4()) + '","correlationToken": "'+ token +'","payloadVersion": "3"},"endpoint": {"endpointId": "' + id_device + '"},"payload": {}},"context": {"properties": [{"namespace": "Alexa.ThermostatController","name": "thermostatMode","value": "' + Temp_target + '", "timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '","uncertaintyInMilliseconds": 500}]}}'
                    return "Alexa.ThermostatController", Temp_target, risposta
                
                elif(stato=="AdjustTargetTemperature"):
                    #aumenta di 5 gradi la temperatura del termostato
                    #diminuisci di 5 gradi la temperatura del termostato
                    
                    delta_target = data['directive']['payload']['targetSetpointDelta']['value']
                    
                    #vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": "AdjustTargetTemperature" , "temp" : delta_target, "identificativo": id_device}))
                    
                    t_target = "0"
                    risp = dynamodb.get_item(TableName='ESP8266_smarthome_devicestate', Key={'id': {'S': id_device + "_S"}})
                    if 'Item' in risp:
                        item = risp['Item']
                        value_Temp = item['stato']['S']
                        t_target = value_Temp

                    Temp_target = delta_target + float(t_target)
                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": "temp",  "t" : Temp_target, "identificativo": id_device}))
                    risposta = '{"event": {"header": {"namespace": "Alexa","name": "Response","messageId": "' + str(uuid.uuid4()) + '","correlationToken": "'+ token +'","payloadVersion": "3"},"endpoint": {"endpointId": "' + id_device + '"},"payload": {}},"context": {"properties": [{"namespace": "Alexa.ThermostatController","name": "targetSetpoint","value": {"value": "' + str(Temp_target) + '","scale": "CELSIUS"},"timeOfSample": "' + time.strftime("%Y-%m-%dT%H:%M:%S.00Z", time.gmtime(None)) + '","uncertaintyInMilliseconds": 500}]}}'
                    return "Alexa.ThermostatController", Temp_target, risposta

            elif((dev['capabilities'][0]['interface'] == 'Alexa.LockController') and (dev['endpointId'] == id_device)):
                
                if(stato=="Unlock"):
                    #alexa, sblocca il portone

                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": stato, "identificativo": id_device}))
                    barer_token = token
                    risposta = '{"event":{"header":{"namespace":"Alexa","name":"Response","messageId":"'+str(uuid.uuid4())+'","correlationToken":"'+token+'","payloadVersion":"3"},"endpoint":{"scope":{"type":"BearerToken","token":"'+barer_token+'"},"endpointId":"'+id_device+'"},"payload":{}},"context":{"properties":[{"namespace":"Alexa.LockController","name":"lockState","value":"UNLOCKED","timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds":1000}]}}'

                    return "Alexa.LockController", 'UNLOCKED', risposta

            elif((dev['capabilities'][0]['interface'] == 'Alexa.RangeController') and (dev['endpointId'] == id_device)):
                if((stato=="AdjustRangeValue")or(stato=="SetRangeValue")):
                    #shutter, persiane , finestre
                    #alexa, alza finestra bagno
                    #alexa, abbassa finestra bagno
                    #alexa, apri finestra bagno
                    #alexa, chiudi finestra bagno
                    #alexa, alza del 20% la finestra bagno
                    #alexa, abbassa del 40% finestra bagno

                    instanza = data['directive']['header']['instance']
                    
                    if(stato=="SetRangeValue"):
                        range = str(data['directive']['payload']['rangeValue'])
                    else:
                        range = str(data['directive']['payload']['rangeValueDelta'])
                    
                    vl = mqtt.publish(topic='ESP8266/out',qos=1,payload=json.dumps({"tipo" : tipo, "stato": range, "identificativo": id_device}))

                    risposta = '{"event":{"header":{"namespace":"Alexa","name":"Response","messageId":"'+str(uuid.uuid4())+'","correlationToken":"'+token+'","payloadVersion":"3"},"endpoint":{"scope":{"type":"BearerToken","token":"'+token+'"},"endpointId":"'+id_device+'"},"payload":{}},"context":{"properties":[{"namespace":"Alexa.RangeController","instance":"'+instanza+'","name":"rangeValue","value":"'+range+'","timeOfSample":"'+time.strftime("%Y-%m-%dT%H:%M:%S.00Z",time.gmtime(None))+'","uncertaintyInMilliseconds":500}]}}'

                    return "Alexa.RangeController", '', risposta

        else:
            pass





"""


if __name__ == "__main__":
    dis = Dispositivi()
    d = dis.get_Dispositivi()


    print(d['event']['header'])

    dispraw = dis.get_Dispositivi()
    disp = dispraw['event']['payload']['endpoints']
    for dev in disp:
        print(dev)
        print("---------------------------------")

"""
