import logging
import time
import json
import uuid
import urllib3
import boto3
from boto3.dynamodb.conditions import Key, Attr
from Dispositivi import *
from AutorizzazioneEventi import *


aws_access_key_id = "xxxxxxxxxxxxxxxx"
aws_secret_access_key = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
region_name="eu-west-1"
awsiot_mqtt = boto3.client('iot-data', aws_access_key_id=aws_access_key_id,aws_secret_access_key=aws_secret_access_key,region_name=region_name)
dynamodb = boto3.client('dynamodb', aws_access_key_id=aws_access_key_id,aws_secret_access_key=aws_secret_access_key,region_name=region_name)


logger = logging.getLogger()
logger.setLevel(logging.INFO)

# x console
#handler = logging.StreamHandler()
#handler.setLevel(logging.INFO)
#logger.addHandler(handler)


def lambda_handler(request, context):
    #logger.info("*********************************")       
    #logger.info(request)       

    try:
        nome = request["directive"]["header"]["name"]
        if (nome == 'AcceptGrant'):                                                             #Token Key x Eventi Asincroni
            risposta = None
            code = request["directive"]["payload"]["grant"]["code"]
            token = request["directive"]["payload"]["grantee"]["token"]

            client_id = ''  # prese da App , alexa skill messaging
            client_secret = '' #come sopra

            autorizzazione_eventi = AutorizzazioneEventi(client_id , client_secret)
            access_token, refresh_token = autorizzazione_eventi.get_authorization_code(code)
            logger.info(access_token)
            logger.info(refresh_token)

            risp = dynamodb.update_item(TableName='ESP8266_SmartHome_credential_token_event', Key={'app': {'S': 'ESP8266_smarthome_iot_event'}}, AttributeUpdates={'access_token' : {'Value' : {'S' : access_token}}, 'refresh_token' : {'Value' : {'S' : refresh_token}}   })
            if(risp['ResponseMetadata']['HTTPStatusCode'] == 200):
                risposta = '{"event": {"header": {"namespace": "Alexa.Authorization","name": "AcceptGrant.Response","payloadVersion": "3","messageId": "' + str(uuid.uuid4()) + '"},"payload": {}}}'            
            return json.loads(risposta)

        if (nome == 'Discover'):                                                                #Alexa Richiede Numero e Tipo di Device
            device = Dispositivi()
            return device.get_Dispositivi()

        elif (nome == 'ReportState'):                                                           #Eventi Sincroni, Alexa richiede stato dei Device
            token = request["directive"]["header"]["correlationToken"]
            id_device = request["directive"]["endpoint"]["endpointId"]

            logger.info("-------REPORT STATE-------")
            logger.info(request)   
            logger.info("--------------------------")


            device = Dispositivi()
            tipo, value, risposta, *varie = device.get_State_Device(dynamodb, id_device, token)
            logger.info("-------RESPONSE-------")
            logger.info(risposta)   
            
            return json.loads(risposta)

        else:                                                                                   #Alexa Invia Comandi al Device
            namespace = request["directive"]["header"]["namespace"]
            name = request["directive"]["header"]["name"]
            id_device = request["directive"]["endpoint"]["endpointId"]
            token = request["directive"]["header"]["correlationToken"]

            logger.info("-------SET COMMAND--------")
            logger.info(request)   
            logger.info("--------------------------")

            device = Dispositivi()
            tipo, value, risposta, *varie = device.set_State_Device(dynamodb, awsiot_mqtt,namespace,name,id_device,token , request)

            logger.info("-------RESPONSE-------")
            logger.info(risposta)   
            
            return json.loads(risposta)

    except ValueError as error:
        logger.error(error)
        raise












"""
if __name__ == "__main__":
    programma = 3

    if (programma == 1):    #simula , Alexa invia , Alexa.Discovery
        s = '{"directive": {"header": {"namespace": "Alexa.Discovery", "name": "Discover", "payloadVersion": "3", "messageId": "87474f16-48ab-4e77-9902-f80d76858d01"}, "payload": {"scope": {"type": "BearerToken", "token": "Atza|IwEBICNiLljq5qAH2VIDC9nIk8Rk0oTtq_AWYdPriQTUg5YnmXLbFh42QdhoSwRCtJX7Qt0Oq7aQv-pn85CI6lpMh0-XInN8RVK7GGm3eBOWfiGveRH-D0zpkC3HYDoPbDAiiFC_h9jsAhrafwY5ti0vF7fyTQ84erCMs0M8fN6h_bEqBPqQ7HWUgkFsMGMbdaQI-Q45x1ffoBLzXHGQNOES0SwLjCJLJ9-7qIcKsVRA1y2aJFU1a66-YLnP-P3kT8j5P_ffw8cVNUZJLdMiqd-tNL1dYWnLwBrRrOGjBVMpIoW0icyXYns1YauwcDxMzz3QzsYh1QaydnqCv36BIHcmBNDtcsoSQZENgqBz-RJ_0CWWIZeA9WpECNKquf8R0SRCfHp6gTCfPgPQC5piVOPQ0DOoz4a7MCoABDQn_WOZPnJg_u1DsSmkiKgS4TEmttbHP0MeJyhWUq_zGJx0GMdVz0eKCUusIVnpVVpCcqE5YCXusW_wPXMrYAdbz8rfkTtPWRS2uxfWsDw_VvZ-w2rUv5piz4aLJBcbr4q2Eed9GQCGVA"}}}}'
        convs = json.loads(s)
        risposta = lambda_handler(convs, None)
        logger.info(risposta)

    elif(programma == 2):   #simula comando Alexa.PowerController
        s = '{"directive": {"header": {"namespace": "Alexa.PowerController", "name": "TurnOn", "payloadVersion": "3", "messageId": "58e17b8a-024b-42e3-8d3c-695a14b04851", "correlationToken": "AAAAAAAAAQDs+VAXGQuXDnAOQC8F0syaDAIAAAAAAAA8QCHyzfYaNdjZpCLsstK0A9EJ34ldODsYkO2MRT2D+KSDxhwf3EULLZ5vgWPTdRi8lhA5cEVLaQPPDfjURpdUgQ+ZsBSr1wgUo8/dwt1awowZpbUgMQ+C3iiZasMFMU6J+6y1s+eyZ9tiA/pVaWNXY13jKVZY6n4pU0agjSK61+oJl3wOHGhaMtwe9ftdTI9i2Spb+m/ZrcI52lg5mGYPhjZUXcgeSGAA/jc90Z0eLxrbveClSWURSwcEawcsHs4sjN3WK86EW/jsBhIJv9MMmUS5PCcQny/clvqbTnN3oUiWuo+qGRXEjK3KrTJTH2RGYDQbjCu0ZJYxKstyx607t4fKOoPo0PfGXsw6ZYxM6KMpC0bDhJVKN4p/MK1U+p3kvohm3qQdc6/IMto1lqRjqqkdec67Zk+kdQomQzoKH8I/r7Jcwj1q2t2PlUZqXklegetejq4Jj+A6yysvwLLTTrzxORPR4Ux7I25bE516PRpJTbiYLC9Sdn2p0LtbLxVg+uPZm4zFNu6Yz38/ZbUNZ8Fgyr9/PfpeqfIWIJA/M0fjanJcliTAToF3SY3iXStfMD+5sebQzSDrga4A74c3ETNacWA59Qt9ZQOJmnZusbHRDGdHe3tTixfVcydcdwbCQ1P2KukPHLw0HcaPjdss8G/TsoEKE5ZUhNxTPU5zmcB/m1imC0zzOAOKaw=="}, "endpoint": {"scope": {"type": "BearerToken", "token": "Atza|IwEBICNiLljq5qAH2VIDC9nIk8Rk0oTtq_AWYdPriQTUg5YnmXLbFh42QdhoSwRCtJX7Qt0Oq7aQv-pn85CI6lpMh0-XInN8RVK7GGm3eBOWfiGveRH-D0zpkC3HYDoPbDAiiFC_h9jsAhrafwY5ti0vF7fyTQ84erCMs0M8fN6h_bEqBPqQ7HWUgkFsMGMbdaQI-Q45x1ffoBLzXHGQNOES0SwLjCJLJ9-7qIcKsVRA1y2aJFU1a66-YLnP-P3kT8j5P_ffw8cVNUZJLdMiqd-tNL1dYWnLwBrRrOGjBVMpIoW0icyXYns1YauwcDxMzz3QzsYh1QaydnqCv36BIHcmBNDtcsoSQZENgqBz-RJ_0CWWIZeA9WpECNKquf8R0SRCfHp6gTCfPgPQC5piVOPQ0DOoz4a7MCoABDQn_WOZPnJg_u1DsSmkiKgS4TEmttbHP0MeJyhWUq_zGJx0GMdVz0eKCUusIVnpVVpCcqE5YCXusW_wPXMrYAdbz8rfkTtPWRS2uxfWsDw_VvZ-w2rUv5piz4aLJBcbr4q2Eed9GQCGVA"}, "endpointId": "endpoint-001", "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}}, "payload": {}}}'
        convs = json.loads(s)
        risposta = lambda_handler(convs, None)
        logger.info(risposta)       
    elif (programma == 3):  #simula , ReportState , stati dei device
        s = '{"directive": {"header": {"namespace": "Alexa", "name": "ReportState", "payloadVersion": "3", "messageId": "73a9c153-c925-4e93-a535-0ae3634dcd0d", "correlationToken": "AAAAAAAAAQDs+VAXGQuXDnAOQC8F0syaDAIAAAAAAABuIdzebvVSRQUlx0fraBIAXxVhUHplZr0yb8sqiU1DiY5NX8a4MjOrqdTYE7p4UKzwz75U6/o4SaIjHL//QiB8KosD6eD1Pfyd2GG0uw0a8HFVYtTmX17QO23yMSGmkT4grRVSnDE+nG6LW1Xlqur3vCOs9POjsy70iT9kjm6E4boKa7eIAbGui4vxBTTlDLvmPivGCyUiT1MnBF7jWE9nmobjRZzXTepxrJPZsqccpt4cdEQ5UoOzxA59v50JjcueM6LlxG+8m/wjZa05L1Mm8ieGsC4MlSaLW6NHk66xsD+LJGHx3OUoYK582CRqfaduNMIhnbMqmp2DioHWQuNfswfTZJ2wmg6XWD3TNEDw0NC3mZifkPZLgk6GGSWd+GYh5kX1o+Qc1sQUU7wTercTj2PBPXvemVSBDz9WV2gXbKpjl0i/tN3WMn6ANfd3EE4lif89RH6Vuzu37/msR8/JAV+o947AEQ8o8bwZUbGBupfdPd6WuwlNuvDIpZo6QvfjMcPiOVnobnta+AqcnC65lJB+Hmz3Z/UuOFGn7XJID3brlQDMU8JNmxhVadZkKYW1o7kE0qCMIiaO/7el8KZ7kAI5J12j3QN0obn/gdBtOpDbBA4j+ufvRyV7ZASfNOuWQFNyo1/jYkS9Nfi8racOcMTdH74MyrfgeU6ddXqARq/5qD1rML98tUAI2A=="}, "endpoint": {"scope": {"type": "BearerToken", "token": "Atza|IwEBICNiLljq5qAH2VIDC9nIk8Rk0oTtq_AWYdPriQTUg5YnmXLbFh42QdhoSwRCtJX7Qt0Oq7aQv-pn85CI6lpMh0-XInN8RVK7GGm3eBOWfiGveRH-D0zpkC3HYDoPbDAiiFC_h9jsAhrafwY5ti0vF7fyTQ84erCMs0M8fN6h_bEqBPqQ7HWUgkFsMGMbdaQI-Q45x1ffoBLzXHGQNOES0SwLjCJLJ9-7qIcKsVRA1y2aJFU1a66-YLnP-P3kT8j5P_ffw8cVNUZJLdMiqd-tNL1dYWnLwBrRrOGjBVMpIoW0icyXYns1YauwcDxMzz3QzsYh1QaydnqCv36BIHcmBNDtcsoSQZENgqBz-RJ_0CWWIZeA9WpECNKquf8R0SRCfHp6gTCfPgPQC5piVOPQ0DOoz4a7MCoABDQn_WOZPnJg_u1DsSmkiKgS4TEmttbHP0MeJyhWUq_zGJx0GMdVz0eKCUusIVnpVVpCcqE5YCXusW_wPXMrYAdbz8rfkTtPWRS2uxfWsDw_VvZ-w2rUv5piz4aLJBcbr4q2Eed9GQCGVA"}, "endpointId": "endpoint-001", "cookie": {"detail1": "For simplicity, this is the only appliance", "detail2": "that has some values in the additionalApplianceDetails"}}, "payload": {}}}'
        convs = json.loads(s)
        risposta = lambda_handler(convs, None)
        logger.info(risposta)       
    else:        
        pass

"""




